# Baby Tomato's Diary — GitHub Pages deployment

## Important: upload the FILES at the repository root
The ZIP is arranged correctly: `index.html` is at the top level, alongside
`manifest.webmanifest`, `sw.js`, and `tomato-icon.svg`.

## Deploy to https://airinohime1-rgb.github.io/Diary-17/
1. Open the GitHub repository named `Diary-17` for account `airinohime1-rgb`.
2. Choose **Add file → Upload files**.
3. Open this ZIP on your device and upload the FOUR site files from inside it
   (`index.html`, `manifest.webmanifest`, `sw.js`, `tomato-icon.svg`) directly
   into the repository's top level. Do not upload the containing folder.
4. Commit the changes to the branch used by GitHub Pages (usually `main`).
5. In the repository, open **Settings → Pages**. Under Build and deployment,
   select **Deploy from a branch**, choose `main` and `/(root)`, then Save.
   If Pages is already configured to use a `/docs` folder or a different branch,
   either change it to `main` + `/(root)` or upload the files to the configured
   publishing folder instead.
6. Wait for the Pages deployment to finish, then refresh the site.

## If it still shows 404
Open the repository's **Actions** tab and check the latest Pages deployment.
Also verify that `index.html` is visible at the root of the selected publishing
branch/folder. A 404 means GitHub Pages is not currently serving an `index.html`
from the configured publishing source, or the URL/repository configuration
does not match.
